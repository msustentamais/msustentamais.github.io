# Como atualizar o site MsustentaMais

Tudo o que muda com frequência fica no arquivo **conteudo.js**. Você não precisa mexer no index.html.

## Arquivos que vão para o GitHub (todos na mesma pasta)
- `index.html` — a estrutura do site (não precisa editar)
- `conteudo.js` — todo o conteúdo que você atualiza
- `robots.txt` e `sitemap.xml` — para o Google encontrar o site
- `logo.png` — opcional; quando existir, aparece no topo e na aba do navegador
- pasta `img/` — opcional, para as fotos

## Passo a passo pelo navegador
1. Entre em github.com/msustentamais e abra o repositório do site.
2. Clique em `conteudo.js` e depois no ícone de lápis (Editar).
3. Copie um bloco existente { ... } e cole logo abaixo dele, trocando os textos.
4. Confira se cada bloco termina com vírgula e se os textos estão entre aspas.
5. Clique em "Commit changes". Em 1 a 2 minutos o site mostra a novidade.

## O que fica onde, dentro do conteudo.js
- **contato**: WhatsApp, e-mail, YouTube e Instagram (YouTube e Instagram só aparecem quando preenchidos).
- **vendas**: links do diagnóstico, do guia, da landing do CEPGAS e da página de compra.
- **fotos**: sua foto em "Quem sou" e a galeria da fazenda em "Meio ambiente".
- **boasPraticas**: as dicas do espaço "Boas práticas". As com data aparecem primeiro, e as 3 mais recentes vão para a página inicial.
- **projetos**: todos os projetos. Os que têm o tema "Cultura" ou "Patrimônio" aparecem também na página Cultura. Use `destaque: true` em até 3 para aparecerem na página inicial.
- **culturaDestaque**: o bloco de destaque da página Cultura (hoje, Cáceres em Sentidos).
- **materias**: links das matérias publicadas na imprensa (aba "Na imprensa").
- **publicacoes**: artigos, livros, apresentações e pesquisas.
- **videos**: vídeos do YouTube (sem link, aparecem como "Em breve").
- **produtos**: produtos e serviços da página "A empresa".
- **marcos**: a linha do tempo da sustentabilidade.

## Se algo sumir do site
Se aparecer uma faixa amarela no topo dizendo que o conteudo.js não carregou,
quase sempre é uma vírgula, aspa ou chave faltando. No GitHub, abra "History" do
arquivo, compare com a versão anterior e corrija.

## Páginas do site
Início · Quem sou · A empresa · CEPGAS™ · Projetos · Cultura · Meio ambiente · Boas práticas · Artigos · Contato
